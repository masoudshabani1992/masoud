<?php
/* بازیکا — ورودی استند زنده (محافظت‌شده) */
require __DIR__ . '/../bz_guard.php';
bz_session_secure();
session_start();
bz_headers();
bz_guard();          // قفل دامنه
$BZ_TOK = bz_token();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title>بازیکا — استند زنده</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🦖</text></svg>" />
  <link rel="stylesheet" href="ui.css?v=9" />
  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap" rel="stylesheet" />
</head>
<body class="portrait">
  <div id="ui">
    <div id="brand"><img src="../assets/logo.png" alt="بازیکا" onerror="this.parentNode.remove()" /></div>

    <div id="frameWrap">
      <div id="standTitle">استند زنده</div>
      <div id="frame">
        <div id="stage"></div>
        <div id="hint">🦖 روی دایناسورها ضربه بزنید!</div>
      </div>
    </div>

    <div id="diag"></div>

    <!-- نوار پایین: پخش صدای راوی + اطلاعات -->
    <div id="bottombar">
      <button id="btnPlay" class="big-btn">▶<span>صدای راوی</span></button>
      <button id="btnMute" class="big-btn" aria-label="قطع/وصل صدا">🔊<span>صدا</span></button>
      <button id="btnInfo" class="big-btn">ℹ<span>اطلاعات</span></button>
    </div>

    <!-- پاپ‌آپ اطلاعات -->
    <div id="popup" class="sheet">
      <div class="box">
        <button class="close" id="popupClose" aria-label="بستن">✖</button>
        <img id="popupImg" alt="" />
        <h3 id="popupName"></h3>
        <ul id="popupRows"></ul>
        <p id="popupFact" class="fact"></p>
      </div>
    </div>

    <!-- پنل متن اطلاعات (دکمهٔ ℹ) -->
    <div id="infoPanel" class="sheet">
      <div class="box">
        <button class="close" onclick="document.querySelector('#infoPanel').classList.remove('open')" aria-label="بستن">✖</button>
        <h3>دربارهٔ این استند 🦖</h3>
        <p id="infoText">متن اطلاعات به‌زودی بارگذاری می‌شود…</p>
      </div>
    </div>

    <div id="toast"></div>
  </div>

  <script>window.BZ_TOKEN = <?php echo json_encode($BZ_TOK); ?>;</script>
  <script src="app.js?v=9"></script>
  <script>
    (function () {
      var d = document.getElementById('diag');
      window.addEventListener('load', function () {
        setTimeout(function () {
          if (d && !window.__BAZIKA_INIT) d.textContent = '⚠ app.js اجرا نشد — THREE:' + (typeof window.THREE);
        }, 1500);
      });
    })();
  </script>
</body>
</html>
