/* global jQuery, wp */
jQuery(function ($) {
  'use strict';
  $(document).on('click', '.arti-select-texture', function (event) {
    event.preventDefault();
    var button = $(this), picker = button.closest('.arti-texture-picker');
    var frame = wp.media({ title: 'انتخاب تصویر تخت بافت سرامیک', button: { text: 'استفاده در استودیو' }, library: { type: 'image' }, multiple: false });
    frame.on('select', function () {
      var image = frame.state().get('selection').first().toJSON();
      picker.find('.arti-texture-id').val(image.id);
      picker.find('.arti-texture-preview').attr('src', (image.sizes && image.sizes.thumbnail ? image.sizes.thumbnail.url : image.url)).prop('hidden', false);
      picker.find('.arti-remove-texture').prop('hidden', false);
    });
    frame.open();
  });
  $(document).on('click', '.arti-remove-texture', function (event) {
    event.preventDefault();
    var picker = $(this).closest('.arti-texture-picker');
    picker.find('.arti-texture-id').val('0');
    picker.find('.arti-texture-preview').removeAttr('src').prop('hidden', true);
    $(this).prop('hidden', true);
  });
});
