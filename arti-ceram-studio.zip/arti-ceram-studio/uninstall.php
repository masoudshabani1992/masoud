<?php
/** Removes plugin settings only. Product configuration and studio pages are retained. */
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
delete_option('arti_ceram_studio_settings');
