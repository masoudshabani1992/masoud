<?php
if (!defined('ABSPATH')) { exit; }

final class Arti_Ceram_Studio_Catalog {
    const ENABLED = '_arti_studio_enabled';
    const TEXTURE = '_arti_studio_texture_id';
    const USAGE = '_arti_studio_usage';
    const WIDTH = '_arti_studio_width_cm';
    const HEIGHT = '_arti_studio_height_cm';
    const FINISH = '_arti_studio_finish';

    public static function settings() {
        return wp_parse_args(get_option('arti_ceram_studio_settings', array()), Arti_Ceram_Studio_Admin::defaults());
    }

    public static function fa_digits($value) {
        return strtr((string) $value, array('0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹'));
    }

    public static function infer_dimensions($title) {
        $title = strtr((string) $title, array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9'));
        if (preg_match('/(\d{1,3}(?:\.\d+)?)\s*[×xX*]\s*(\d{1,3}(?:\.\d+)?)/u', $title, $m)) {
            $w = (float) $m[1]; $h = (float) $m[2];
            if ($w >= 5 && $w <= 240 && $h >= 5 && $h <= 240) { return array($w, $h); }
        }
        return array(60.0, 60.0);
    }

    public static function product_config($post_id) {
        $enabled = get_post_meta($post_id, self::ENABLED, true) === 'yes';
        $texture_id = absint(get_post_meta($post_id, self::TEXTURE, true));
        $usage = get_post_meta($post_id, self::USAGE, true);
        if (!is_array($usage)) { $usage = array('wall'); }
        $usage = array_values(array_intersect(array('floor', 'wall'), $usage));
        $dims = self::infer_dimensions(get_the_title($post_id));
        $width = (float) get_post_meta($post_id, self::WIDTH, true);
        $height = (float) get_post_meta($post_id, self::HEIGHT, true);
        if ($width < 5 || $width > 240) { $width = $dims[0]; }
        if ($height < 5 || $height > 240) { $height = $dims[1]; }
        return array('enabled'=>$enabled, 'texture_id'=>$texture_id, 'usage'=>$usage ?: array('wall'), 'width'=>$width, 'height'=>$height, 'finish'=>sanitize_text_field(get_post_meta($post_id, self::FINISH, true)));
    }

    public static function products() {
        $settings = self::settings();
        if ($settings['source'] === 'demo' || !class_exists('WooCommerce')) { return array(); }
        $ids = get_posts(array(
            'post_type'=>'product', 'post_status'=>'publish', 'numberposts'=>200,
            'orderby'=>'menu_order title', 'order'=>'ASC', 'fields'=>'ids',
            'meta_query'=>array(
                array('key'=>self::ENABLED, 'value'=>'yes'),
                array('key'=>self::TEXTURE, 'value'=>0, 'compare'=>'>', 'type'=>'NUMERIC'),
            ),
        ));
        $result = array();
        foreach ($ids as $id) {
            $product = wc_get_product($id);
            if (!$product || !$product->is_visible()) { continue; }
            $config = self::product_config($id);
            $image = wp_get_attachment_image_url($config['texture_id'], 'large');
            if (!$image || !wp_attachment_is_image($config['texture_id'])) { continue; }
            $categories = get_the_terms($id, 'product_cat');
            $collection = is_array($categories) && isset($categories[0]) ? $categories[0]->name : __('محصولات آرتی سرام', 'arti-ceram-studio');
            $result[] = array(
                'id'=>'wc-' . $id, 'name'=>wp_strip_all_tags($product->get_name()),
                'english'=>$product->get_sku(), 'collection'=>$collection,
                'image'=>$image, 'color'=>'#ded5bb', 'tone'=>'light',
                'finish'=>$config['finish'] ?: __('طبق مشخصات محصول', 'arti-ceram-studio'),
                'usage'=>$config['usage'], 'widthCm'=>$config['width'], 'heightCm'=>$config['height'],
                'dimensions'=>self::fa_digits($config['width'] . ' × ' . $config['height']),
                'description'=>wp_strip_all_tags($product->get_short_description()),
                'url'=>get_permalink($id), 'price'=>wp_strip_all_tags($product->get_price_html()),
                'sku'=>$product->get_sku(), 'source'=>'woocommerce',
            );
        }
        return $result;
    }

    public static function demo_products() {
        $items = array(
            array('travertine-ivory','تراورتن ایوری','IVORY TRAVERTINE','travertine',60,60,'مات'),
            array('calacatta-white','کلکاتا وایت','CALACATTA WHITE','calacatta',60,120,'ساتن'),
            array('concrete-grey','سیمان طوسی','CONCRETE GREY','concrete',80,80,'مات'),
            array('sandstone-beige','سنداستون بژ','SANDSTONE BEIGE','sandstone',60,60,'مات'),
            array('terrazzo-cream','ترازو کرِم','TERRAZZO CREAM','terrazzo',60,60,'مات'),
            array('nero-marquina','نرو مارکینا','NERO MARQUINA','nero',60,120,'ساتن'),
        );
        return array_map(static function ($item) {
            return array('id'=>$item[0],'name'=>$item[1],'english'=>$item[2],
                'image'=>ARTI_CERAM_STUDIO_URL . 'assets/images/' . $item[3] . '.webp',
                'collection'=>'کاتالوگ نمایشی','widthCm'=>$item[4],'heightCm'=>$item[5],
                'dimensions'=>self::fa_digits($item[4] . ' × ' . $item[5]),'finish'=>$item[6],
                'usage'=>array('floor','wall'),'tone'=>$item[0] === 'nero-marquina' ? 'dark' : 'light',
                'description'=>'این محصول برای نمایش عملکرد استودیو است و محصول واقعی فروشگاه نیست.','source'=>'demo');
        }, $items);
    }
}
