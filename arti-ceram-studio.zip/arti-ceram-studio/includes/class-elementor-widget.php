<?php
if (!defined('ABSPATH') || !class_exists('\Elementor\Widget_Base')) { exit; }

final class Arti_Ceram_Studio_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'arti-studio'; }
    public function get_title() { return __('استودیو آرتی سرام', 'arti-ceram-studio'); }
    public function get_icon() { return 'eicon-paint-brush'; }
    public function get_categories() { return array('general'); }
    public function get_keywords() { return array('ceramic', 'studio', 'سرامیک', 'استودیو'); }
    public function get_style_depends() { return array('arti-ceram-studio'); }
    public function get_script_depends() { return array('arti-ceram-studio'); }

    protected function register_controls() {
        $this->start_controls_section('studio_content', array('label'=>__('استودیو طراحی', 'arti-ceram-studio')));
        $this->add_control('product', array('label'=>__('شناسه محصول (اختیاری)', 'arti-ceram-studio'), 'type'=>\Elementor\Controls_Manager::TEXT, 'description'=>__('برای شروع با یک محصول مشخص، شناسه عددی ووکامرس را وارد کنید.', 'arti-ceram-studio')));
        $this->add_control('surface', array('label'=>__('سطح اولیه', 'arti-ceram-studio'), 'type'=>\Elementor\Controls_Manager::SELECT, 'default'=>'wall', 'options'=>array('wall'=>__('دیوار', 'arti-ceram-studio'), 'floor'=>__('کف', 'arti-ceram-studio'))));
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        echo do_shortcode('[arti_ceram_studio product="' . esc_attr($settings['product']) . '" surface="' . esc_attr($settings['surface']) . '"]');
    }
}
