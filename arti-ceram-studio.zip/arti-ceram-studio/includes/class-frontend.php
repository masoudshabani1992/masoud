<?php
if (!defined('ABSPATH')) { exit; }

final class Arti_Ceram_Studio_Frontend {
    private $configured = false;
    private $config = null;

    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        add_shortcode('arti_ceram_studio', array($this, 'shortcode'));
        add_shortcode('arti_studio', array($this, 'shortcode'));
        add_action('woocommerce_after_add_to_cart_form', array($this, 'product_button'));
        add_action('elementor/widgets/register', array($this, 'register_widget'));
        add_filter('plugin_action_links_' . plugin_basename(ARTI_CERAM_STUDIO_FILE), array($this, 'action_links'));
    }

    public function register_assets() {
        wp_register_script('arti-ceram-studio', ARTI_CERAM_STUDIO_URL . 'assets/app.js', array(), ARTI_CERAM_STUDIO_VERSION, true);
        wp_register_style('arti-ceram-studio', ARTI_CERAM_STUDIO_URL . 'assets/app.css', array(), ARTI_CERAM_STUDIO_VERSION);
    }

    private function enqueue() {
        wp_enqueue_script('arti-ceram-studio');
        wp_enqueue_style('arti-ceram-studio');
        if ($this->configured) { return; }
        $this->configured = true;
        $settings = Arti_Ceram_Studio_Catalog::settings();
        $source = $settings['source'] === 'woocommerce' && class_exists('WooCommerce') ? 'woocommerce' : 'demo';
        $products = $source === 'woocommerce' ? Arti_Ceram_Studio_Catalog::products() : Arti_Ceram_Studio_Catalog::demo_products();
        $config = array(
            'assetsUrl'=>ARTI_CERAM_STUDIO_URL . 'assets/', 'products'=>$products, 'source'=>$source,
            'shopUrl'=>function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/'),
            'homeUrl'=>home_url('/'), 'showPrices'=>(bool) $settings['show_prices'],
        );
        /** Allow deliberate integrations/tests to adjust the public catalog. */
        $this->config = apply_filters('arti_ceram_studio_config', $config);
        // Print configuration just before footer scripts, including shortcodes
        // rendered inside block themes and Elementor templates.
        if (!has_action('wp_footer', array($this, 'print_config'))) {
            add_action('wp_footer', array($this, 'print_config'), 19);
        }
    }

    public function print_config() {
        if ($this->config === null || !wp_script_is('arti-ceram-studio', 'enqueued')) { return; }
        $json = wp_json_encode($this->config, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
        if ($json === false) { return; }
        echo wp_get_inline_script_tag('window.ArtiCeramStudioConfig = ' . $json . ';', array('id'=>'arti-ceram-studio-config'));
        $this->config = null;
    }

    public function shortcode($atts = array()) {
        $atts = shortcode_atts(array('product'=>'', 'surface'=>'wall', 'class'=>''), $atts, 'arti_ceram_studio');
        $this->enqueue();
        $surface = $atts['surface'] === 'floor' ? 'floor' : 'wall';
        $product = sanitize_text_field($atts['product']);
        $class = sanitize_html_class($atts['class']);
        return '<div class="arti-studio ' . esc_attr($class) . '" data-arti-studio data-product="' . esc_attr($product) . '" data-surface="' . esc_attr($surface) . '" dir="rtl"><div class="arti-studio-loading" style="padding:60px 20px;text-align:center;font-family:Tahoma,sans-serif;color:#294c3f">در حال آماده‌سازی استودیو طراحی…</div><noscript>برای استفاده از استودیو، جاوااسکریپت مرورگر را فعال کنید.</noscript></div>';
    }

    public function product_button() {
        $settings = Arti_Ceram_Studio_Catalog::settings();
        if (!$settings['product_button'] || !is_product()) { return; }
        $id = get_queried_object_id();
        $config = Arti_Ceram_Studio_Catalog::product_config($id);
        if (!$config['enabled'] || !$config['texture_id']) { return; }
        $page = absint($settings['studio_page']);
        if (!$page || get_post_status($page) !== 'publish') { return; }
        $url = add_query_arg('arti_product', 'wc-' . $id, get_permalink($page));
        echo '<a class="button arti-studio-product-button" style="display:inline-flex;margin:12px 0;gap:8px" href="' . esc_url($url) . '">' . esc_html__('این سرامیک را در فضای من ببینم', 'arti-ceram-studio') . '</a>';
    }

    public function register_widget($manager) {
        if (!did_action('elementor/loaded')) { return; }
        require_once ARTI_CERAM_STUDIO_DIR . 'includes/class-elementor-widget.php';
        $manager->register(new Arti_Ceram_Studio_Elementor_Widget());
    }

    public function action_links($links) {
        array_unshift($links, '<a href="' . esc_url(admin_url('admin.php?page=arti-ceram-studio')) . '">' . esc_html__('تنظیمات استودیو', 'arti-ceram-studio') . '</a>');
        return $links;
    }
}
