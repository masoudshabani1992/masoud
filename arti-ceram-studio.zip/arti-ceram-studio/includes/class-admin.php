<?php
if (!defined('ABSPATH')) { exit; }

final class Arti_Ceram_Studio_Admin {
    const OPTION = 'arti_ceram_studio_settings';
    const NONCE = 'arti_ceram_studio_save';

    public static function defaults() {
        return array('source'=>class_exists('WooCommerce') ? 'woocommerce' : 'demo', 'studio_page'=>0, 'show_prices'=>1, 'product_button'=>1);
    }

    public function __construct() {
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'assets'));
        add_action('admin_post_arti_studio_save_product', array($this, 'save_product'));
        add_action('admin_post_arti_studio_create_page', array($this, 'create_page'));
        add_action('add_meta_boxes_product', array($this, 'metabox'));
        add_action('woocommerce_process_product_meta', array($this, 'save_metabox'));
    }

    public function menu() {
        add_menu_page(__('استودیو آرتی سرام', 'arti-ceram-studio'), __('استودیو آرتی سرام', 'arti-ceram-studio'), 'manage_options', 'arti-ceram-studio', array($this, 'page'), 'dashicons-art', 56);
    }

    public function register_settings() {
        register_setting('arti_ceram_studio', self::OPTION, array('type'=>'array', 'sanitize_callback'=>array($this, 'sanitize_settings'), 'default'=>self::defaults()));
    }

    public function sanitize_settings($input) {
        $input = is_array($input) ? $input : array();
        $page = absint($input['studio_page'] ?? 0);
        if ($page && get_post_type($page) !== 'page') { $page = 0; }
        return array(
            'source'=>isset($input['source']) && $input['source'] === 'demo' ? 'demo' : 'woocommerce',
            'studio_page'=>$page,
            'show_prices'=>empty($input['show_prices']) ? 0 : 1,
            'product_button'=>empty($input['product_button']) ? 0 : 1,
        );
    }

    public function assets($hook) {
        $screen = get_current_screen();
        if (strpos($hook, 'arti-ceram-studio') === false && (!$screen || $screen->id !== 'product')) { return; }
        wp_enqueue_media();
        wp_enqueue_script('arti-ceram-studio-admin', ARTI_CERAM_STUDIO_URL . 'assets/admin.js', array('jquery'), ARTI_CERAM_STUDIO_VERSION, true);
        wp_enqueue_style('arti-ceram-studio-admin', ARTI_CERAM_STUDIO_URL . 'assets/admin.css', array(), ARTI_CERAM_STUDIO_VERSION);
    }

    public function metabox() {
        add_meta_box('arti-studio-product', __('استودیو طراحی آرتی سرام', 'arti-ceram-studio'), array($this, 'metabox_content'), 'product', 'side', 'default');
    }

    public function metabox_content($post) {
        $config = Arti_Ceram_Studio_Catalog::product_config($post->ID);
        $this->product_fields($post->ID, $config, 'metabox');
    }

    public function save_metabox($post_id) {
        if (!isset($_POST['arti_studio_product_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['arti_studio_product_nonce'])), self::NONCE)) { return; }
        if (!current_user_can('edit_post', $post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) { return; }
        $this->persist_product($post_id, $_POST);
    }

    public function save_product() {
        if (!current_user_can('manage_options')) { wp_die(esc_html__('دسترسی مجاز نیست.', 'arti-ceram-studio')); }
        check_admin_referer(self::NONCE);
        $id = absint($_POST['product_id'] ?? 0);
        if (!$id || get_post_type($id) !== 'product') { wp_die(esc_html__('محصول پیدا نشد.', 'arti-ceram-studio')); }
        $this->persist_product($id, $_POST);
        wp_safe_redirect(add_query_arg(array('page'=>'arti-ceram-studio', 'updated'=>'1', 'product_search'=>sanitize_text_field(wp_unslash($_POST['product_search'] ?? ''))), admin_url('admin.php')));
        exit;
    }

    private function persist_product($id, $data) {
        $texture = absint($data['texture_id'] ?? 0);
        if ($texture && !wp_attachment_is_image($texture)) { $texture = 0; }
        $enabled = !empty($data['enabled']) && $texture;
        update_post_meta($id, Arti_Ceram_Studio_Catalog::ENABLED, $enabled ? 'yes' : 'no');
        update_post_meta($id, Arti_Ceram_Studio_Catalog::TEXTURE, $texture);
        $usage = isset($data['usage']) && is_array($data['usage']) ? array_values(array_intersect(array('floor','wall'), array_map('sanitize_key', $data['usage']))) : array();
        update_post_meta($id, Arti_Ceram_Studio_Catalog::USAGE, $usage ?: array('wall'));
        $dims = Arti_Ceram_Studio_Catalog::infer_dimensions(get_the_title($id));
        $width = (float) ($data['width'] ?? 0); $height = (float) ($data['height'] ?? 0);
        update_post_meta($id, Arti_Ceram_Studio_Catalog::WIDTH, $width >= 5 && $width <= 240 ? $width : $dims[0]);
        update_post_meta($id, Arti_Ceram_Studio_Catalog::HEIGHT, $height >= 5 && $height <= 240 ? $height : $dims[1]);
        update_post_meta($id, Arti_Ceram_Studio_Catalog::FINISH, sanitize_text_field(wp_unslash($data['finish'] ?? '')));
    }

    public function create_page() {
        if (!current_user_can('manage_pages') || !current_user_can('manage_options')) { wp_die(esc_html__('دسترسی مجاز نیست.', 'arti-ceram-studio')); }
        check_admin_referer('arti_studio_create_page');
        $settings = Arti_Ceram_Studio_Catalog::settings();
        $page = absint($settings['studio_page']);
        if (!$page || get_post_status($page) !== 'publish') {
            $page = wp_insert_post(array('post_type'=>'page', 'post_status'=>'publish', 'post_title'=>'استودیو طراحی آرتی سرام', 'post_content'=>'[arti_ceram_studio]'), true);
            if (!is_wp_error($page)) {
                $settings['studio_page'] = $page;
                update_option(self::OPTION, $settings);
            }
        }
        wp_safe_redirect(admin_url('admin.php?page=arti-ceram-studio&created=' . (is_wp_error($page) ? '0' : '1')));
        exit;
    }

    private function product_fields($id, $config, $context = 'page') {
        $image = $config['texture_id'] ? wp_get_attachment_image_url($config['texture_id'], 'thumbnail') : '';
        if ($context === 'metabox') { wp_nonce_field(self::NONCE, 'arti_studio_product_nonce'); }
        include ARTI_CERAM_STUDIO_DIR . 'includes/product-fields.php';
    }

    public function page() {
        if (!current_user_can('manage_options')) { return; }
        $settings = Arti_Ceram_Studio_Catalog::settings();
        $search = sanitize_text_field(wp_unslash($_GET['product_search'] ?? ''));
        $query = new WP_Query(array('post_type'=>'product', 'post_status'=>'publish', 'posts_per_page'=>20, 's'=>$search, 'orderby'=>'title', 'order'=>'ASC',
            'paged'=>max(1, absint($_GET['paged'] ?? 1))));
        include ARTI_CERAM_STUDIO_DIR . 'includes/settings-page.php';
    }
}
