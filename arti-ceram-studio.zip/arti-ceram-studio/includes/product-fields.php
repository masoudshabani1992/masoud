<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="arti-admin-product-fields" data-product-id="<?php echo esc_attr($id); ?>">
    <p><label><input type="checkbox" name="enabled" value="1" <?php checked($config['enabled']); ?> /> <?php esc_html_e('نمایش در استودیو طراحی', 'arti-ceram-studio'); ?></label></p>
    <p class="description"><?php esc_html_e('تصویر بافت باید تخت، رو‌به‌رو و بدون قاب یا چیدمان اتاق باشد. عکس شاخص محصول به‌صورت خودکار استفاده نمی‌شود.', 'arti-ceram-studio'); ?></p>
    <div class="arti-texture-picker">
        <img class="arti-texture-preview" src="<?php echo esc_url($image); ?>" alt="" <?php echo $image ? '' : 'hidden'; ?> />
        <input type="hidden" name="texture_id" class="arti-texture-id" value="<?php echo esc_attr($config['texture_id']); ?>" />
        <button type="button" class="button arti-select-texture"><?php esc_html_e('انتخاب تصویر بافت', 'arti-ceram-studio'); ?></button>
        <button type="button" class="button-link arti-remove-texture" <?php echo $image ? '' : 'hidden'; ?>><?php esc_html_e('حذف تصویر', 'arti-ceram-studio'); ?></button>
    </div>
    <p><label><?php esc_html_e('کاربرد تأییدشده', 'arti-ceram-studio'); ?></label><br/>
        <label><input type="checkbox" name="usage[]" value="wall" <?php checked(in_array('wall', $config['usage'], true)); ?> /> <?php esc_html_e('دیوار', 'arti-ceram-studio'); ?></label>
        <label style="margin-inline-start:14px"><input type="checkbox" name="usage[]" value="floor" <?php checked(in_array('floor', $config['usage'], true)); ?> /> <?php esc_html_e('کف', 'arti-ceram-studio'); ?></label>
    </p>
    <p class="description"><?php esc_html_e('فقط کاربرد درج‌شده در مشخصات فنی محصول را فعال کنید؛ مناسب بودن برای کف از ظاهر عکس قابل تشخیص نیست.', 'arti-ceram-studio'); ?></p>
    <p class="arti-dimension-fields">
        <label><?php esc_html_e('عرض (cm)', 'arti-ceram-studio'); ?><input type="number" name="width" min="5" max="240" step="0.1" value="<?php echo esc_attr($config['width']); ?>" /></label>
        <label><?php esc_html_e('طول (cm)', 'arti-ceram-studio'); ?><input type="number" name="height" min="5" max="240" step="0.1" value="<?php echo esc_attr($config['height']); ?>" /></label>
    </p>
    <p><label><?php esc_html_e('پرداخت سطح', 'arti-ceram-studio'); ?><input type="text" name="finish" maxlength="60" value="<?php echo esc_attr($config['finish']); ?>" placeholder="<?php esc_attr_e('مات، براق، ساتن…', 'arti-ceram-studio'); ?>" /></label></p>
</div>
