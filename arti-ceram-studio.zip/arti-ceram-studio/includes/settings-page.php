<?php if (!defined('ABSPATH') || !current_user_can('manage_options')) { exit; } ?>
<div class="wrap arti-admin-wrap">
    <h1><?php esc_html_e('استودیو طراحی آرتی سرام', 'arti-ceram-studio'); ?> <span class="arti-version">1.1.0</span></h1>
    <?php if (isset($_GET['updated'])) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e('تنظیمات محصول ذخیره شد.', 'arti-ceram-studio'); ?></p></div><?php endif; ?>
    <?php if (isset($_GET['created'])) : ?><div class="notice notice-<?php echo $_GET['created'] === '1' ? 'success' : 'error'; ?> is-dismissible"><p><?php echo $_GET['created'] === '1' ? esc_html__('برگه استودیو آماده شد.', 'arti-ceram-studio') : esc_html__('ساخت برگه ممکن نشد؛ دسترسی ساخت برگه را بررسی کنید.', 'arti-ceram-studio'); ?></p></div><?php endif; ?>
    <div class="arti-admin-grid">
        <section class="arti-admin-card">
            <h2><?php esc_html_e('۱. برگه استودیو', 'arti-ceram-studio'); ?></h2>
            <p><?php esc_html_e('شورت‌کد زیر را در یک برگه، ابزارک شورت‌کد المنتور یا ویجت اختصاصی استودیو قرار دهید.', 'arti-ceram-studio'); ?></p>
            <code class="arti-shortcode" dir="ltr">[arti_ceram_studio]</code>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="arti_studio_create_page" />
                <?php wp_nonce_field('arti_studio_create_page'); ?>
                <button class="button button-primary"><?php esc_html_e('ساخت برگه استودیو', 'arti-ceram-studio'); ?></button>
                <?php if ($settings['studio_page'] && get_post_status($settings['studio_page']) === 'publish') : ?><a class="button" target="_blank" rel="noopener" href="<?php echo esc_url(get_permalink($settings['studio_page'])); ?>"><?php esc_html_e('مشاهده استودیو', 'arti-ceram-studio'); ?></a><?php endif; ?>
            </form>
            <p class="description"><?php esc_html_e('اگر برگه‌ای دارید، فقط شورت‌کد را داخل آن بگذارید و در تنظیمات کنار انتخاب کنید. برای نمایش تمام‌عرض در المنتور، قالب صفحه را Canvas یا تمام‌عرض بگذارید.', 'arti-ceram-studio'); ?></p>
        </section>
        <section class="arti-admin-card">
            <h2><?php esc_html_e('۲. تنظیمات عمومی', 'arti-ceram-studio'); ?></h2>
            <form method="post" action="options.php">
                <?php settings_fields('arti_ceram_studio'); ?>
                <table class="form-table" role="presentation">
                    <tr><th><label for="arti-source"><?php esc_html_e('منبع محصولات', 'arti-ceram-studio'); ?></label></th><td><select id="arti-source" name="arti_ceram_studio_settings[source]"><option value="woocommerce" <?php selected($settings['source'], 'woocommerce'); ?>><?php esc_html_e('محصولات واقعی ووکامرس', 'arti-ceram-studio'); ?></option><option value="demo" <?php selected($settings['source'], 'demo'); ?>><?php esc_html_e('کاتالوگ نمایشی', 'arti-ceram-studio'); ?></option></select><?php if (!class_exists('WooCommerce')) : ?><p class="description"><?php esc_html_e('ووکامرس فعال نیست؛ فعلاً کاتالوگ نمایشی نمایش داده می‌شود.', 'arti-ceram-studio'); ?></p><?php endif; ?></td></tr>
                    <tr><th><label for="arti-page"><?php esc_html_e('برگه استودیو', 'arti-ceram-studio'); ?></label></th><td><?php wp_dropdown_pages(array('name'=>'arti_ceram_studio_settings[studio_page]', 'id'=>'arti-page', 'selected'=>$settings['studio_page'], 'show_option_none'=>'— انتخاب کنید —', 'option_none_value'=>0)); ?></td></tr>
                    <tr><th><?php esc_html_e('نمایش قیمت', 'arti-ceram-studio'); ?></th><td><label><input type="checkbox" name="arti_ceram_studio_settings[show_prices]" value="1" <?php checked($settings['show_prices']); ?> /> <?php esc_html_e('قیمت فعلی ووکامرس در کتابخانه نمایش داده شود.', 'arti-ceram-studio'); ?></label></td></tr>
                    <tr><th><?php esc_html_e('صفحه محصول', 'arti-ceram-studio'); ?></th><td><label><input type="checkbox" name="arti_ceram_studio_settings[product_button]" value="1" <?php checked($settings['product_button']); ?> /> <?php esc_html_e('دکمه «این سرامیک را در فضای من ببینم» زیر محصول فعال باشد.', 'arti-ceram-studio'); ?></label></td></tr>
                </table>
                <?php submit_button(__('ذخیره تنظیمات', 'arti-ceram-studio')); ?>
            </form>
        </section>
    </div>
    <section class="arti-admin-card arti-admin-catalog">
        <h2><?php esc_html_e('۳. آماده‌سازی محصولات واقعی', 'arti-ceram-studio'); ?></h2>
        <div class="notice notice-info inline"><p><?php esc_html_e('برای هر محصول، تصویر بافت تخت را از کتابخانه رسانه انتخاب کنید، ابعاد و کاربرد فنی را بررسی کنید و «نمایش در استودیو» را فعال کنید. تا زمانی که محصولی فعال نشده باشد، کاتالوگ واقعی خالی می‌ماند؛ محصولات نمونه جایگزین آن نمی‌شوند.', 'arti-ceram-studio'); ?></p></div>
        <p><?php esc_html_e('این تنظیمات را می‌توانید از جعبه «استودیو طراحی آرتی سرام» در صفحه ویرایش هر محصول نیز انجام دهید. قیمت، نام و لینک خرید مستقیماً از ووکامرس خوانده می‌شوند.', 'arti-ceram-studio'); ?></p>
        <form method="get" class="arti-product-search"><input type="hidden" name="page" value="arti-ceram-studio" /><input type="search" name="product_search" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('جست‌وجوی محصول…', 'arti-ceram-studio'); ?>" /><button class="button"><?php esc_html_e('جست‌وجو', 'arti-ceram-studio'); ?></button></form>
        <?php if (!$query->have_posts()) : ?><p><?php esc_html_e('محصولی پیدا نشد. ابتدا محصولات ووکامرس را منتشر کنید یا عبارت جست‌وجو را تغییر دهید.', 'arti-ceram-studio'); ?></p><?php endif; ?>
        <?php while ($query->have_posts()) : $query->the_post(); $id = get_the_ID(); $config = Arti_Ceram_Studio_Catalog::product_config($id); ?>
            <form class="arti-product-row" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="arti_studio_save_product" /><input type="hidden" name="product_id" value="<?php echo esc_attr($id); ?>" /><input type="hidden" name="product_search" value="<?php echo esc_attr($search); ?>" />
                <?php wp_nonce_field(Arti_Ceram_Studio_Admin::NONCE); ?>
                <div class="arti-product-row-title"><span class="arti-product-status <?php echo $config['enabled'] ? 'enabled' : ''; ?>"><?php echo $config['enabled'] ? esc_html__('فعال', 'arti-ceram-studio') : esc_html__('غیرفعال', 'arti-ceram-studio'); ?></span><h3><?php the_title(); ?></h3><a target="_blank" rel="noopener" href="<?php echo esc_url(get_edit_post_link($id)); ?>"><?php esc_html_e('ویرایش محصول', 'arti-ceram-studio'); ?></a></div>
                <?php $this->product_fields($id, $config); ?>
                <button class="button button-primary"><?php esc_html_e('ذخیره محصول', 'arti-ceram-studio'); ?></button>
            </form>
        <?php endwhile; wp_reset_postdata(); ?>
        <div class="tablenav"><div class="tablenav-pages"><?php echo wp_kses_post(paginate_links(array('total'=>$query->max_num_pages, 'current'=>max(1, absint($_GET['paged'] ?? 1)), 'base'=>add_query_arg('paged', '%#%'), 'format'=>''))); ?></div></div>
    </section>
    <section class="arti-admin-card"><h2><?php esc_html_e('حریم خصوصی و محدودیت‌ها', 'arti-ceram-studio'); ?></h2><p><?php esc_html_e('عکس فضای کاربر در مرورگر پردازش می‌شود و به سرور ارسال نمی‌شود. طرح‌ها در حافظه همان مرورگر ذخیره می‌شوند. تشخیص سطح دستی و پیش‌نمایش تقریبی است؛ این افزونه متراژ یا تعداد کاشی را محاسبه نمی‌کند. تصاویر بافت را از دامنه خود سایت انتخاب کنید تا خروجی تصویر با محدودیت CORS مواجه نشود.', 'arti-ceram-studio'); ?></p><p><?php esc_html_e('پس از به‌روزرسانی تنظیمات، کش صفحه، CDN و کش افزونه بهینه‌سازی را پاک کنید. جاوااسکریپت استودیو فقط در صفحه‌ای که شورت‌کد دارد بارگیری می‌شود.', 'arti-ceram-studio'); ?></p></section>
</div>
