<?php
/**
 * Plugin Name: استودیو طراحی آرتی سرام
 * Plugin URI: https://rtceram.com/
 * Description: پیش‌نمایش سرامیک‌های ووکامرس روی کف و دیوار عکس کاربر. شورت‌کد [arti_ceram_studio] را در یک برگه قرار دهید.
 * Version: 1.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Arti Ceram
 * Text Domain: arti-ceram-studio
 * Domain Path: /languages
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) { exit; }

define('ARTI_CERAM_STUDIO_VERSION', '1.1.0');
define('ARTI_CERAM_STUDIO_FILE', __FILE__);
define('ARTI_CERAM_STUDIO_DIR', plugin_dir_path(__FILE__));
define('ARTI_CERAM_STUDIO_URL', plugin_dir_url(__FILE__));

require_once ARTI_CERAM_STUDIO_DIR . 'includes/class-catalog.php';
require_once ARTI_CERAM_STUDIO_DIR . 'includes/class-admin.php';
require_once ARTI_CERAM_STUDIO_DIR . 'includes/class-frontend.php';

register_activation_hook(__FILE__, static function () {
    if (get_option('arti_ceram_studio_settings', null) === null) {
        add_option('arti_ceram_studio_settings', Arti_Ceram_Studio_Admin::defaults());
    }
});

add_action('plugins_loaded', static function () {
    load_plugin_textdomain('arti-ceram-studio', false, dirname(plugin_basename(__FILE__)) . '/languages');
    new Arti_Ceram_Studio_Frontend();
    if (is_admin()) { new Arti_Ceram_Studio_Admin(); }
});
